sns.PHP
-------------
网易微博、百度、Google、微软、Instagram、Facebook、360、GitHub、淘宝等平台的账号登录及api操作，使用oauth 2.0  
官方提供的sdk都太过庞大，这是我自己简化的，提供简单的账号登录、获取个人信息、发布微博等功能，如果需要其他功能可以根据官方的api文档自行添加

文件说明
-------------
>**t163.php** 网易微博  
>**baidu.php** 百度  
>**google.php** Google  
>**live.php** 微软  
>**instagram.php** Instagram  
>**facebook.php** Facebook  
>**360.php** 360  
>**github.php** GitHub  
>**taobao.php** 淘宝  
>**t163_demo.php** 网易微博示例程序  
>**t163_config.php** 网易微博示例程序配置  
>**t163_callback.php** 网易微博示例程序回调文件

相关信息
-------------
新浪微博、腾讯微博、QQ、人人网、开心网、豆瓣等平台的账号登录及api操作请查看[Git @ OSC](http://git.oschina.net/piscdong/)

开发者信息
-------------
[PiscDong studio](http://www.piscdong.com/)
