<?php
//配置文件
header('Content-Type: text/html; charset=UTF-8');

$t163_k=''; //腾讯微博应用App Key
$t163_s=''; //腾讯微博应用App Secret
$callback_url='http://yoururl/t163_callback.php'; //授权回调网址
